# Income-Prediction
Income Prediction app
